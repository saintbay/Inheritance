﻿//#include <iostream>
//
//template <typename T>
//struct Node {
//    T data;
//    Node* next;
//    Node* prev;
//};
//
//template <typename T>
//class Queue {
//private:
//    Node<T>* head;
//    Node<T>* tail;
//    size_t size;
//
//public:
//    Queue() : head(nullptr), tail(nullptr), size(0) {}
//
//    ~Queue() {
//        while (!isEmpty()) {
//            dequeue();
//        }
//    }
//
//    bool isEmpty() const {
//        return size == 0;
//    }
//
//    void enqueue(const T& value) {
//        Node<T>* newNode = new Node<T>{ value, nullptr, tail };
//        if (tail) {
//            tail->next = newNode;
//        }
//        else {
//            head = newNode;
//        }
//        tail = newNode;
//        size++;
//    }
//
//    T dequeue() {
//        if (isEmpty()) {
//            throw std::out_of_range("Queue is empty!");
//        }
//        Node<T>* temp = head;
//        T value = head->data;
//        head = head->next;
//        if (head) {
//            head->prev = nullptr;
//        }
//        else {
//            tail = nullptr;
//        }
//        delete temp;
//        size--;
//        return value;
//    }
//
//    T front() const {
//        if (isEmpty()) {
//            throw std::out_of_range("Queue is empty!");
//        }
//        return head->data;
//    }
//
//    size_t getSize() const {
//        return size;
//    }
//
//    void printQueue() const {
//        Node<T>* current = head;
//        std::cout << "Очередь: ";
//        while (current) {
//            std::cout << current->data << " ";
//            current = current->next;
//        }
//        std::cout << std::endl;
//    }
//};
//
//int main() {
//    setlocale(LC_ALL, "Russian");
//    Queue<int> queue;
//
//    queue.enqueue(10);
//    queue.enqueue(20);
//    queue.enqueue(30);
//    queue.printQueue();
//
//    std::cout << "Удаляем элемент: " << queue.dequeue() << std::endl;
//    queue.printQueue();
//
//    queue.enqueue(40);
//    queue.printQueue();
//
//    std::cout << "Элемент в начале: " << queue.front() << std::endl;
//
//    return 0;
//}
//
//
//
//
//
//
//
//
//#include <iostream>
//
//template <typename T>
//struct Node {
//    T data;
//    Node* next;
//    Node* prev;
//};
//
//template <typename T>
//class DoublyLinkedList {
//private:
//    Node<T>* head;
//    Node<T>* tail;
//
//public:
//    DoublyLinkedList() : head(nullptr), tail(nullptr) {}
//
//    ~DoublyLinkedList() {
//        while (head) {
//            Node<T>* temp = head;
//            head = head->next;
//            delete temp;
//        }
//    }
//
//    void append(const T& value) {
//        Node<T>* newNode = new Node<T>{ value, nullptr, tail };
//        if (tail) {
//            tail->next = newNode;
//        }
//        else {
//            head = newNode;
//        }
//        tail = newNode;
//    }
//
//    void printList() const {
//        Node<T>* current = head;
//        while (current) {
//            std::cout << current->data << " ";
//            current = current->next;
//        }
//        std::cout << std::endl;
//    }
//
//    DoublyLinkedList<T> clone() const {
//        DoublyLinkedList<T> copy;
//        Node<T>* current = head;
//        while (current) {
//            copy.append(current->data);
//            current = current->next;
//        }
//        return copy;
//    }
//
//    DoublyLinkedList<T> operator+(const DoublyLinkedList<T>& other) const {
//        DoublyLinkedList<T> result = this->clone();
//        Node<T>* current = other.head;
//        while (current) {
//            result.append(current->data);
//            current = current->next;
//        }
//        return result;
//    }
//
//    DoublyLinkedList<T> operator*(const DoublyLinkedList<T>& other) const {
//        DoublyLinkedList<T> result;
//        Node<T>* current1 = head;
//        while (current1) {
//            Node<T>* current2 = other.head;
//            while (current2) {
//                if (current1->data == current2->data) {
//                    result.append(current1->data);
//                    break;
//                }
//                current2 = current2->next;
//            }
//            current1 = current1->next;
//        }
//        return result;
//    }
//};
//
//int main() {
//    setlocale(LC_ALL, "Russian");
//    DoublyLinkedList<int> list1, list2;
//
//    list1.append(1);
//    list1.append(2);
//    list1.append(3);
//
//    list2.append(2);
//    list2.append(3);
//    list2.append(4);
//
//    std::cout << "Первый список: ";
//    list1.printList();
//
//    std::cout << "Второй список: ";
//    list2.printList();
//
//    std::cout << "Объединение списков: ";
//    DoublyLinkedList<int> mergedList = list1 + list2;
//    mergedList.printList();
//
//    std::cout << "Общие элементы: ";
//    DoublyLinkedList<int> commonList = list1 * list2;
//    commonList.printList();
//
//    return 0;
//}
//
//






#include <iostream>
#include <vector>

template <typename T>
class Array {
private:
    std::vector<T> data;
    int grow;

public:
    Array(int initialSize = 0, int growFactor = 1) : grow(growFactor) {
        data.resize(initialSize);
    }

    int GetSize() const {
        return data.size();
    }

    void SetSize(int size, int growFactor = 1) {
        grow = growFactor;
        data.resize(size);
    }

    int GetUpperBound() const {
        return data.size() - 1;
    }

    bool IsEmpty() const {
        return data.empty();
    }

    void FreeExtra() {
        data.shrink_to_fit();
    }

    void RemoveAll() {
        data.clear();
    }

    T GetAt(int index) const {
        if (index < 0 || index >= data.size()) {
            throw std::out_of_range("Index out of range");
        }
        return data[index];
    }

    void SetAt(int index, const T& value) {
        if (index < 0 || index >= data.size()) {
            throw std::out_of_range("Index out of range");
        }
        data[index] = value;
    }

    T& operator[](int index) {
        return data[index];
    }

    void Add(const T& value) {
        if (data.size() >= data.capacity()) {
            data.reserve(data.size() + grow);
        }
        data.push_back(value);
    }

    void Append(const Array<T>& other) {
        data.insert(data.end(), other.data.begin(), other.data.end());
    }

    Array<T>& operator=(const Array<T>& other) {
        data = other.data;
        grow = other.grow;
        return *this;
    }

    const T* GetData() const {
        return data.data();
    }

    void InsertAt(int index, const T& value) {
        if (index < 0 || index > data.size()) {
            throw std::out_of_range("Index out of range");
        }
        data.insert(data.begin() + index, value);
    }

    void RemoveAt(int index) {
        if (index < 0 || index >= data.size()) {
            throw std::out_of_range("Index out of range");
        }
        data.erase(data.begin() + index);
    }

    void printArray() const {
        for (const auto& elem : data) {
            std::cout << elem << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    setlocale(LC_ALL, "Russian");
    Array<int> array(5, 3);

    array.SetAt(0, 10);
    array.Add(20);
    array.Add(30);

    array.printArray();

    array.InsertAt(1, 15);
    array.printArray();

    array.RemoveAt(2);
    array.printArray();

    return 0;
}
